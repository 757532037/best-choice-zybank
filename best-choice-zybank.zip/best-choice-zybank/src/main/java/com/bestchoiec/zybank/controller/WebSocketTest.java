package com.bestchoiec.zybank.controller;
import java.awt.List;
import java.io.IOException;
import java.util.ArrayList;

import javax.websocket.OnClose;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.server.ServerEndpoint;


@ServerEndpoint("/websocketTest")
public class WebSocketTest {
	
    @OnMessage
    public void onMessage(String message, javax.websocket.Session session) throws IOException, InterruptedException {

        // Print the client message for testing purposes
        System.out.println("Received: " + message);
        System.out.println("Connection onMessage"+session.getId());
        // Send the first message to the client
        session.getBasicRemote().sendText("This is the first server message");

        // Send 3 messages to the client every 5 seconds
        int sentMessages = 0;
//        while (sentMessages < 3) {
//            Thread.sleep(5000);
        String font = "<font style=\"color: red;\">��ɫ</font> <font style=\"color: yellow;\">��ɫ</font> <font style=\"color: blue;\">��ɫ</font>";
        String site = "<a href=\"http://192.168.0.138:18080/best-choice-zybank/stu/welcome\">BN</a>";
        session.getBasicRemote().sendText("This is an intermediate server message. Count: " + sentMessages
        		+font+site);
//            sentMessages++;
//        }
//        SocketFactory.SOCKETLIST.add(session);
        // Send a final message to the client
//        session.getBasicRemote().sendText("This is the last server message");
    }

    @OnOpen
    public void onOpen(javax.websocket.Session session) {
    	System.out.println("Connection connected"+session.getId());
        System.out.println("Client connected");
    }

    @OnClose
    public void onClose(javax.websocket.Session session) {
        System.out.println("Connection closed"+session.getId());
        System.out.println("Connection connected");
//        SocketFactory.SOCKETLIST.remove(session);
    }
    
}