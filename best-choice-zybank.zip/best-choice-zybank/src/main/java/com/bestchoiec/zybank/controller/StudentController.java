package com.bestchoiec.zybank.controller;

import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;

import javax.servlet.http.HttpServletRequest;
import javax.websocket.Session;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.bestchoice.business.zybank.service.IstudentService;


@Controller
@RequestMapping("/stu")
public class StudentController {

	@Autowired
	private IstudentService studentService;
	
	@ResponseBody
	@RequestMapping("/welcome")
	public String welcome(HttpServletRequest request){
		System.out.println("*********************************"+studentService.getStudentNameById("123"));
		;
		System.out.println("remorteaddr:"+request.getRemoteAddr());
		System.out.println("remortehost:"+request.getRemoteHost());
		System.out.println("remorteport:"+request.getRemotePort());
		System.out.println("remorteuser:"+request.getRemoteUser());
		System.out.println("phoneNo[{}]"+request.getSession().getAttribute("phoneNo"));
		System.out.println("����Host[{}]"+ request.getRemoteHost());
		System.out.println("����Addr[{}]"+ request.getRemoteAddr());
		System.out.println("�����ַ[{}]"+ reqIp(request));
		return "SUCCESS";
	}
	
	  public String reqIp(HttpServletRequest request){
	    	String client_ip = request.getHeader("x-forwarded-for");
		    if(client_ip == null || client_ip.length() == 0 || "unknown".equalsIgnoreCase(client_ip)) {
		        client_ip = request.getHeader("Proxy-Client-IP");
		    }
		    if(client_ip == null || client_ip.length() == 0 || "unknown".equalsIgnoreCase(client_ip)) {
		        client_ip = request.getHeader("WL-Proxy-Client-IP");
		    }
		    if(client_ip == null || client_ip.length() == 0 || "unknown".equalsIgnoreCase(client_ip)) {
		        client_ip = request.getRemoteAddr();
		        if(client_ip.equals("127.0.0.1") || client_ip.equals("0:0:0:0:0:0:0:1")){
		            //��������ȡ�������õ�IP
		            InetAddress inet = null;
		            try {
		                inet = InetAddress.getLocalHost();
		            } catch (UnknownHostException e) {
		                e.printStackTrace();
		            }
		            client_ip = inet.getHostAddress();
		        }  
		    }  
		    //����ͨ������������������һ��IPΪ�ͻ�����ʵIP,���IP����','�ָ�  
		    if(client_ip != null && client_ip.length() > 15){ //"***.***.***.***".length() = 15  
		        if(client_ip.indexOf(",") > 0){
		            client_ip = client_ip.substring(0,client_ip.indexOf(","));
		        }
		    }
		    
		    String server_ip="";
		    try {
			server_ip = InetAddress.getLocalHost().getHostAddress();
		    } catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		    }
		    return server_ip;
	    }
	
	  @ResponseBody
	  @RequestMapping("/pubadver")
	  public void pubadver(String msg){
		  for(Session session:SocketFactory.SOCKETLIST){
			  try {
				session.getBasicRemote().sendText(msg);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  }
	  }
	  
	  @ResponseBody
	  @RequestMapping("/getHostname")
	  public void getHostname(){
		 
		  HttpServletRequest request = ((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getRequest();
		  System.out.println(request.getAttribute("key"));;
		  System.out.println(request.getParameter("key"));;
		  System.out.println(request.getSession().getAttribute("hostname"));;
		  
		  
	  }
	  
}
